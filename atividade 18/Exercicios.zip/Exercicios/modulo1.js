const text = "oie"
module.exports = text